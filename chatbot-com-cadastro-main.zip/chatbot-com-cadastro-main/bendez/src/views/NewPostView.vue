<script setup>
</script>

<template>
  <main>
    <h1>New Posts</h1>
  </main>
</template>